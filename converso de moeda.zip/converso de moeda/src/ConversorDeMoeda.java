import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import org.json.JSONObject;

public class ConversorDeMoeda {

    private static final String API_KEY = "48a74e0aed775adf25a887f6"; // Substitua pela sua chave
    private static final String BASE_URL = "https://v6.exchangerate-api.com/v6/";

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Conversor de Moeda");
            System.out.println("Escolha as moedas que deseja converter:");
            System.out.println("1 - Dólar para Real");
            System.out.println("2 - Real para Dólar");
            System.out.println("3 - Euro para Real");
            System.out.println("4 - Real para Euro");
            System.out.println("5 - Libra Esterlina para Real");
            System.out.println("6 - Real para Libra Esterlina");
            System.out.println("7 - Iene para Real");
            System.out.println("8 - Real para Iene");

            int escolha = scanner.nextInt();
            System.out.print("Digite o valor a ser convertido: ");
            double valor = scanner.nextDouble();

            String moedaOrigem = "", moedaDestino = "";

            switch (escolha) {
                case 1 -> { moedaOrigem = "USD"; moedaDestino = "BRL"; }
                case 2 -> { moedaOrigem = "BRL"; moedaDestino = "USD"; }
                case 3 -> { moedaOrigem = "EUR"; moedaDestino = "BRL"; }
                case 4 -> { moedaOrigem = "BRL"; moedaDestino = "EUR"; }
                case 5 -> { moedaOrigem = "GBP"; moedaDestino = "BRL"; }
                case 6 -> { moedaOrigem = "BRL"; moedaDestino = "GBP"; }
                case 7 -> { moedaOrigem = "JPY"; moedaDestino = "BRL"; }
                case 8 -> { moedaOrigem = "BRL"; moedaDestino = "JPY"; }
                default -> {
                    System.out.println("Opção inválida!");
                    return;
                }
            }

            double taxaConversao = obterTaxaDeCambio(moedaOrigem, moedaDestino);
            double resultado = valor * taxaConversao;
            System.out.printf("%.2f %s equivalem a %.2f %s\n", valor, moedaOrigem, resultado, moedaDestino);
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    private static double obterTaxaDeCambio(String moedaOrigem, String moedaDestino) throws Exception {
        String urlString = BASE_URL + API_KEY + "/latest/" + moedaOrigem;
        HttpURLConnection connection = (HttpURLConnection) new URL(urlString).openConnection();
        connection.setRequestMethod("GET");

        if (connection.getResponseCode() != 200) {
            throw new Exception("Erro ao conectar à API. Código: " + connection.getResponseCode());
        }

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            StringBuilder resposta = new StringBuilder();
            String linha;
            while ((linha = reader.readLine()) != null) {
                resposta.append(linha);
            }
            JSONObject jsonObject = new JSONObject(resposta.toString());
            return jsonObject.getJSONObject("conversion_rates").getDouble(moedaDestino);
        }
    }
}
